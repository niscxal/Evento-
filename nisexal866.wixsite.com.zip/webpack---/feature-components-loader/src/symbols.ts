export const ComponentsLoaderSymbol = Symbol('ComponentsLoader')
export const ComponentsRegistrarSymbol = Symbol('ComponentsRegistrar')
export const ComponentWrapperSymbol = Symbol('ComponentWrapper')
export const name = 'componentsLoader'
