export const SeoPageSymbol = Symbol('Seo')
export const SeoSiteSymbol = Symbol('SeoSite')

export const name = 'seo' as const
