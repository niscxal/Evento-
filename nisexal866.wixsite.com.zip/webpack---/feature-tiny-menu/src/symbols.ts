export const name = 'tinyMenu' as const
