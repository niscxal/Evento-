export const name = 'wixapps' as const
