export const DEFAULT_EXPIRATION_TIME = 210 * 60 * 1000 // 210 minutes = 3.5 hours
export const META_SITE_APP_ID = -666
