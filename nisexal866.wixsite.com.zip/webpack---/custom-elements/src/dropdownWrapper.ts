import { initCustomElementsDropdownMenu } from './elements/wixDropdownMenu/initCustomElementsDropdownMenu'

initCustomElementsDropdownMenu()
