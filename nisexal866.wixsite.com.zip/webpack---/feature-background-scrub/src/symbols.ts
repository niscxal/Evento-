export const BackgroundScrubSymbol = Symbol('BackgroundScrub')

export const name = 'backgroundScrub' as const
