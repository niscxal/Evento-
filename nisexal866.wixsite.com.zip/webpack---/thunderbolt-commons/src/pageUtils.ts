export const getPageBackgroundId = (pageId: string) => `pageBackground_${pageId}`
