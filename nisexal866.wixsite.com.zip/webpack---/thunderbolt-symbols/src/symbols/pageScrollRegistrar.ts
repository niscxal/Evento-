export const PageScrollRegistrarSymbol = Symbol.for('PageScrollRegistrar')
