export const SiteAssetsClientSym = Symbol('SiteAssetsClient')
export const SiteAssetsClientFactorySym = Symbol('SiteAssetsClientFactory')
