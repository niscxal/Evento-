export const PlatformResetCompsSymbol = Symbol('PlatformResetComps')
export const LivePreviewEnvDataSetterSymbol = Symbol('LivePreviewEnvDataSetterSymbol')
export const ControllersInvokerSymbol = Symbol('ControllersInvoker')
export const LivePreviewApiSymbol = Symbol('livePreviewApi')
