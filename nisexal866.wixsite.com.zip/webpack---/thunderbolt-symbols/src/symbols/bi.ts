export const BISymbol = Symbol.for('BI')
export const WixBiSessionSymbol = Symbol.for('WixBiSessionSymbol')
export const AppNameSymbol = Symbol.for('appName')
